public class own 
{
    public void func()
    {
        int num=123;
        int sum=0;

        for(int i=0;i<=num;i++)
        {
            
        }
     
    }
}
