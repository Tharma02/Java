import java.util.Scanner;

class Program
{
    public static void main(String args[])
    {
        Scanner val=new Scanner(System.in);

        int num=val.nextInt();

        int sum=0,pro=1;

        while(num>0)
        {
            sum=sum+(num%10);
            pro=pro*(num%10);
            num=num/10;
        }

        System.out.println(sum+" "+pro);

        if(sum==pro) System.out.println("Spy Number");

        else System.out.println("No Spy Number");

    }
}