import java.util.Scanner;

class Program
{
    public static void main(String args[])
    {
        Scanner val=new Scanner(System.in);

        System.out.print("Enter a NUmber :");
        String str=val.nextLine();

        String revstr="";

        for(int i=0;i<=str.length();i++)
        {
            char ch=str.charAt(i);
            revstr=revstr+ch;
        }
        System.out.print(revstr);
    }
}