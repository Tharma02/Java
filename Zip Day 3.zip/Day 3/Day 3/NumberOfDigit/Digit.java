import java.util.Scanner;

class Digit
{
   public static void main(String args[])
   {
      Scanner val=new Scanner(System.in);

      int num=val.nextInt();

      int count=0;

      while(num>0)
      {
            num=num/10;
            count++;
      }

      System.out.print(count);
   }

   
}