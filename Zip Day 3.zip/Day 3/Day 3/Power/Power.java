import java.util.Scanner;

class Power
{
    public static void main(String args[])
    {
        Scanner val=new Scanner(System.in);

        System.out.print("Enter a Base value :");
        int base=val.nextInt();

        System.out.print("Enter a Power value :");
        int power=val.nextInt();

        double result=Math.pow(base, power);

        if(base>=0 && power>=0)
        {
            System.out.println(result);
        }
        else System.out.println("Invalid Number");
    }
}