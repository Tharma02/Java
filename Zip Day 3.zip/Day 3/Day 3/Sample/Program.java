import java.util.Scanner;

class Program
{
     public static void main(String[] args)
     {
        Scanner val=new Scanner(System.in);

        System.out.println("Enter a number :");
        int num=val.nextInt();

        int result=0;

        for(int i=2;i<num;i++)
        {
            if(num%i==0)
            {
                result=1;
                break;
            }
        }

        if(result==0)
        {
            System.out.print("Prime");
        }
        else
        {
            System.out.print("Not Prime");
        }


     }
}