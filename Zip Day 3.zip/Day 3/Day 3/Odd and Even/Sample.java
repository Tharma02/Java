import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import javax.lang.model.util.ElementScanner6;
import javax.naming.spi.ResolveResult;

class Sample
{
    public static void main(String args[])
    {
        Scanner obj=new Scanner(System.in);

        System.out.print("Enter a Number :");
        int num=obj.nextInt();

        List<Integer> lst=new ArrayList<Integer>();

        for(int i=1;i<=num;i++)
        {
            if(i%2==0)
            {
                //System.out.print(i + " ");
                lst.add(i);
            }
        }
        System.out.print(lst + " ");
    }
}