import java.util.Scanner;

import javax.swing.text.StyledEditorKit;

class Program
{
    public static void main(String args[])
    {
        Scanner val=new Scanner(System.in);

        System.out.print("Enter a Amstrong number :");
        String num=val.nextLine();

        System.out.print("Length :" + num.length());

        System.out.println();

        int num1=Integer.parseInt(num);
        int[] arm={num1};

        System.out.println(arm[0]);

        // double res=0;

        // for(int i=1;i<=num.length();i++)
        // {
        //     int num1=Integer.parseInt(num);
        //     res=Math.pow(i,num1);
        // }
        // System.out.print(res);
    }
}