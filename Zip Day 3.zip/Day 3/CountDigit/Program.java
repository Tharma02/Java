import java.util.Scanner;

class Program
{
    public static void main(String args[])
    {
        Scanner val=new Scanner(System.in);

        System.out.print("Enter a value :");
        String value=val.nextLine();

        //String s=Integer.toString(value);

        System.out.print("Count value is :" + value.length());
    }
}